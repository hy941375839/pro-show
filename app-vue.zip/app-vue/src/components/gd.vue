<template>
<body data-spy="scroll" data-target="#myScrollspy" data-offset="50">
<div class="container">
    <!--<h1 class="text-center">导航栏</h1>-->
    <div class="fixed-top bg-light">
        <ul class="nav  nav-justified row text-left">
            <li class="nav-item p-2  col-sm-1"><a href="#"><img class="w-10" src="./images/返回.png" alt=""></a></li>
            <li class="nav-item p-2 col-sm-10">
                <div class="input-group ">
                    <input  type="text" class="form-control p-0" placeholder="请输入你要搜索的内容">
                    <div class="input-group-append h-75 ">
                        <a href="#">
                            <img class="btn p-0 " src="./images/搜索.png"></a></div>
                </div>
            </li>
            <li class="nav-item p-2 col-sm-1"><a><img class="w-10" src="./images/添加.png" alt=""></a></li>
        </ul>
        <ul class="nav nav-tabs text-center justify-content-between">
            <li class="nav-item "><a data-toggle="tab" class="nav-link active" href="#tab1">点菜</a></li>
            <li class="nav-item "><a data-toggle="tab" class="nav-link" href="#tab2">评价</a></li>
            <li class="nav-item "><a data-toggle="tab" class="nav-link" href="#tab3">商家</a></li>
            <li class="nav-item "><a data-toggle="tab" class="nav-link" href="#tab4">好友拼单</a></li>
        </ul>
    </div>
</div>
<div class="tab-content ">
<div id="tab1" class="container-fluid  tab-pane active">
    <div class="row mt-5
    ">
        <nav class="col-sm-2 col-4" id="myScrollspy">
            <ul class="nav nav-pills flex-column">
                <li class="nav-item">
                    <a class="nav-link active" href="#section1">热卖</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#section2">折扣</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#section3">进店必买</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" data-toggle="dropdown" href="#">店长推荐</a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="#section41">炒菜</a>
                        <a class="dropdown-item" href="#section42">甜点</a>
                    </div>
                </li>
            </ul>
        </nav>
        <div class="col-sm-10 col-8">
            <div id="section1" class="">
                <h1>热卖</h1>
                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/爆炸虾仁.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">爆炸虾仁</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>

                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/牛扒.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">牛扒</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>
                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/红烧排骨.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">红烧排骨</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>
            </div>
            <div id="section2" class="">
                <h1>折扣</h1>
                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/爆炸虾仁.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">爆炸虾仁</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>

                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/牛扒.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">牛扒</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>
                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/红烧排骨.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">红烧排骨</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>
            </div>
            <div id="section3" class="">
                <h1>进店必买</h1>
                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/爆炸虾仁.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">爆炸虾仁</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>

                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/牛扒.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">牛扒</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>
                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/红烧排骨.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">红烧排骨</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>
            </div>
            <div id="section41" class="">
                <h1>炒菜</h1>
                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/爆炸虾仁.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">爆炸虾仁</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>

                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/牛扒.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">牛扒</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>
                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/红烧排骨.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">红烧排骨</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>
            </div>
            <div id="section42" class="">
                <h1>甜点</h1>

                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/披萨.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">披萨</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>
                <div>
                    <ul class="d-flex list-unstyled justify-content-start">
                        <li>
                            <img class="float-left" src="./images/冰激凌.jpg" alt=""/></li>
                        <li><div class="">
                            <h2 class="text-center m-0">冰激凌</h2>
                            <p class="m-0">使用新鲜海虾制作，保证新鲜</p>
                            <p class="m-0">月售:645&nbsp;&nbsp;赞:16</p>
                            <h4 class="m-0">￥30/份(400g)
                                <a class="gm " href="#"><img  src="./images/购买.png" alt=""/></a></h4></div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
    <div id="tab2" class="tab-pane">钵钵鸡，担担面，火锅</div>
    <div id="tab3" class="tab-pane">虾饺，佛跳墙</div>
    <div id="tab4" class="tab-pane">煎饼，烙饼卷大葱，扒鸡</div>
</div>
<div style="height:88px" class="fixed-bottom bg-info dbqy row">
    <div class="col-sm-3"><a href="#"><img style="height: 80px"  src="./images/购物车.png" alt=""/></a></div>
    <div class="col-sm-3 mt-4"><h3>总价:￥30</h3>另需￥3元配送费</div>
    <div class="col-sm-6 text-center"><a href="#"><img style=" height: 80px" src="./images/结账.png" alt=""/></a></div>
</div>
</body>
  
</template>

<script>
export default {
data(){
  return{}
}
}
</script>

<style>
 body {
            position: relative;
        }
        /* 滚动监听左边指示条*/
        ul.nav-pills {
            top: 100px;
            position: fixed;
        }
        /*单个区域框（热卖的大小）*/
        div.col-8 div {
            height: 600px;
        }
        /* 热卖等区域内单个商品区域大小*/
        div.col-8 div div{height: 30%}
        /*商品区域图片大小*/
        div .col-8 img{width:260px;height: 130px;margin:10px;}
        /*添加按钮大小*/
        a.gm img{width: 30px;height: 30px}
       #section1{margin-top: 50px;}
        #tab2,#tab3,#tab4 {
            margin-top: 100px;
        }
 .dbqy{height: 88px}
</style>