<template>
  <div>
    <button>←</button>
    <input type="text">
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>