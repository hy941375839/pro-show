<template>
<div>
 <div class="container">
    <!--<h1 class="text-center">状态栏</h1>-->
    <div id="ztl" class="row mb-1">
        <img class="col-sm-3" src="../assets/BILIBILI_LOGO.png" alt=""/>
        <h4 class="col-sm-6 text-center mt-2">用户模块</h4>
        <a class="col-sm-3 mt-2" href="#">已登录</a>
    </div>
    <!--<h1 class="text-center">导航栏</h1>-->
    <div>
    <ul class="nav  nav-justified row text-left">
        <li class="nav-item p-2  col-sm-1"><a href="#"><img class="w-10" src="../assets/返回.png" alt=""></a></li>
        <li class="nav-item p-2 col-sm-10">
            <div class="input-group ">
                <input  type="text" class="form-control p-0" placeholder="请输入你要搜索的内容">
                <div class="input-group-append h-75 ">
                    <a href="#">
                        <img class="btn p-0 " src="../assets/搜索.png"></a></div>
            </div>
        </li>
        <li class="nav-item p-2 col-sm-1"><a href="#"><img  src="../assets/添加.png" alt=""></a></li>
    </ul>
    </div>


    <h3 class="text-center">今日热门</h3>
    <div class="carousel" data-ride="carousel" id="demo">
        <!--1轮播图片-->
        <div class="carousel-inner row">
            <div class="carousel-item col-sm-6 col-md-12 active">
                <img  src="../assets/冰激凌.jpg"  alt=""/>
            </div>
            <div class="carousel-item col-sm-6 col-md-12" >
                <img src="../assets/披萨.jpg" alt=""/>
            </div>
            <div class="carousel-item col-sm-6 col-md-12">
                <img src="../assets/爆炸虾仁.jpg" alt=""/>
            </div>
            <div class="carousel-item col-sm-6 col-md-12">
                <img src="../assets/虾仁玉米.jpg" alt=""/>
            </div>
        </div>

        <!--2左右箭头-->
        <a data-slide="prev" href="#demo" class="carousel-control-prev">
            <span class="carousel-control-prev-icon"></span>
        </a>
        <a data-slide="next" href="#demo" class="carousel-control-next">
            <span class="carousel-control-next-icon"></span>
        </a>
        <!--3轮播指示器-->
        <ul class="carousel-indicators">
            <li data-target="#demo" data-slide-to="0" class="active"></li>
            <li data-target="#demo" data-slide-to="1"></li>
            <li data-target="#demo" data-slide-to="2"></li>
            <li data-target="#demo" data-slide-to="3"></li>
        </ul>
    </div>
    <!-- 560x728-->
    <!--<h1>菜品</h1>-->
    <!-- 第一个店-->
    <div class="">
        <ul class="list-unstyled">
            <li>
                <ul class="list-unstyled row">
                    <li class="col-sm-9"><h4><a href="#">特色中餐（人民东路店)</a><img class="ml-4" src="../assets/叫外卖.png" alt=""/></h4></li>
                    <li class="col-sm-3 ">
                        <a href="#" class="btn btn-outline-primary btn-sm rounded "><img  src="../assets/删除.png" alt=""/></a></li>
                 </ul>
            </li>
            <li class="mr-2">
                <ul class="list-unstyled row">
                    <li class="col-sm-7 "><p ><code>4.3分</code>|起送价:￥20|配送费:￥2</p></li>
                    <li class="col-sm-5">配送时间:30分钟</li>
                </ul>
            </li>
            <li>
                <span class="badge bg-danger text-white  ml-3 mr-2">优惠</span>
               满20减8；满30减12
            </li>
            <li>
            <div class="cdjj">
            <table class="text-center">
                <tr>
                    <td class="p-1"><a href="#"><img  src="../assets/披萨.jpg" alt=""/></a></td>
                    <td class="p-1"><a href="#"><img  src="../assets/冰激凌.jpg" alt=""/></a></td>
                    <td class="p-1"><a href="#"><img  src="../assets/牛扒.jpg" alt=""/></a></td>
                </tr>
                <tr>
                    <td><h3>披萨</h3></td>
                    <td><h3>冰激凌</h3></td>
                    <td><h3>牛扒</h3></td>
                </tr>
            </table>
            </div>
            </li>
        </ul>
    </div>
<!--   第二个店 -->
    <div class="">
        <ul class="list-unstyled">
            <li>
                <ul class="list-unstyled row">
                    <li class="col-sm-9"><h4><a href="#">特色中餐（人民东路店)</a><img class="ml-4" src="../assets/叫外卖.png" alt=""/></h4></li>
                    <li class="col-sm-3 ">
                        <a href="#" class="btn btn-outline-primary btn-sm rounded "><img  src="../assets/删除.png" alt=""/></a></li>
                </ul>
            </li>
            <li class="mr-2">
                <ul class="list-unstyled row">
                    <li class="col-sm-7 "><p ><code>4.3分</code>|起送价:￥20|配送费:￥2</p></li>
                    <li class="col-sm-5">配送时间:30分钟</li>
                </ul>
            </li>
            <li>
                <span class="badge bg-danger text-white  ml-3 mr-2">优惠</span>
                满20减8；满30减12
            </li>
            <li>
                <div class="cdjj">
                    <table class="text-center">
                        <tr>
                            <td class="p-1"><a href="#"><img  src="../assets/披萨.jpg" alt=""/></a></td>
                            <td class="p-1"><a href="#"><img  src="../assets/冰激凌.jpg" alt=""/></a></td>
                            <td class="p-1"><a href="#"><img  src="../assets/牛扒.jpg" alt=""/></a></td>
                        </tr>
                        <tr>
                            <td><h3>披萨</h3></td>
                            <td><h3>冰激凌</h3></td>
                            <td><h3>牛扒</h3></td>
                        </tr>
                    </table>
                </div>
            </li>
        </ul>
    </div>
    <!-- 底部-->
    <!-- <div class="db">
        <ul class="list-unstyled d-flex justify-content-around py-4">
            <li><a href="#"><img  src="./images/主页.png" alt=""/>
                <h5 class="text-muted text-center font_small">主页</h5></a></li>
            <li><a href="#"><img src="./images/我的.png" alt=""/>
                <h5 class="text-muted text-center font_small">我的</h5></a>
            </li>
            <li><a href="#"><img src="./images/外卖.png" alt=""/>
                <h5 class="text-muted text-center font_small">外卖</h5></a>
            </li>
        </ul>
    </div> -->
</div>
</div>
  
</template>
<script>
export default {
data(){
  return{}
}
}
</script>
<style  scoped>
 .col-sm-6  img{width:290px;height: 182px;margin: 10px; }
     .col-md-12 img{width:100%;height:320px }
     .nav .nav-item a .w-10 img{width: 32px}
     #ztl{height: 50px;background: #fafafa}
     #ztl img{height:45px; }
     /*菜单菜品简介图片样式*/
     .cdjj table .p-1 img{
         width: 100%;
         height: 150px;
     }
</style>